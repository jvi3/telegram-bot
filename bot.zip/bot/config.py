BOT_TOKEN = "7808916980:AAEi-Jazwkgqqv6_zrb86rb44zEvC4N0Zf0"
CHANNEL_URL = "https://t.me/cassgetinfo"
CHANNEL_ID = "@cassgetinfo"
ADMIN_ID =  6010319577
REF_URL = "https://1wzvro.top/casino/list?open=register&p=20hr"